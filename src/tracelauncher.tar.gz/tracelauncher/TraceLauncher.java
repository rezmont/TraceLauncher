/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tracelauncher;

import automation.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author motamedi
 */
public class TraceLauncher {

	boolean makeFolder = true;
	final Map<String, String> launcherPointer;

	public TraceLauncher() {
		this.launcherPointer = new HashMap<>();
		launcherPointer.put("net_he", "automation.HE");
		launcherPointer.put("net_level3", "automation.Level3");
		launcherPointer.put("net_sprint", "automation.Sprint");
		launcherPointer.put("net_nlayer", "automation.NLayer");
		launcherPointer.put("net_fdc", "automation.FDC");
		launcherPointer.put("net_trit", "automation.Trit");
		launcherPointer.put("net_iptp", "automation.IPTP");
		launcherPointer.put("net_ntt", "automation.NTT");
		launcherPointer.put("net_asdasd", "automation.ASDASD");
		launcherPointer.put("net_clearfly", "automation.Clearfly");
		launcherPointer.put("net_appliedops", "automation.AOps");
		launcherPointer.put("net_atlmetro", "automation.AtlMetro");
		launcherPointer.put("net_telia", "automation.Telia");
		launcherPointer.put("edu_aarnet", "automation.AARNet");
		launcherPointer.put("net_tac", "automation.Telus");
		launcherPointer.put("net_tata", "automation.Tata");
		launcherPointer.put("com_pipe", "automation.PIPE");
		launcherPointer.put("net_velia", "automation.Velia");
		launcherPointer.put("com_phyber", "automation.Phyber");
		launcherPointer.put("net_eurorings", "automation.KPN");
		launcherPointer.put("net_bboi", "automation.BBOI");
		launcherPointer.put("net_hwng", "automation.Highwinds");
		launcherPointer.put("net_totiig", "automation.TOTIIG");
		launcherPointer.put("com_virtutel", "automation.VirtuTel");
		launcherPointer.put("com_hostvirtual", "automation.HostVirtual");
		launcherPointer.put("com_towardex", "automation.Towardex");
		launcherPointer.put("net_integra", "automation.Integra");
		launcherPointer.put("net_nexicom", "automation.Nexicom");
		launcherPointer.put("net_infowest", "automation.InfoWest");
		launcherPointer.put("com_webex", "automation.Webex");
		launcherPointer.put("net_iinet", "automation.iiNet");
		launcherPointer.put("net_emix", "automation.Emix");
		launcherPointer.put("net_arpnetworks", "automation.OpenBGPD");
		launcherPointer.put("net_peer1", "automation.Peer1");
		launcherPointer.put("com_vocus", "automation.Vocus");
		launcherPointer.put("co_vibe", "automation.Vibe");
		launcherPointer.put("com_flagtel", "automation.Flagtel");
		launcherPointer.put("mn_gemnet", "automation.Gemnet");
		launcherPointer.put("net_retn", "automation.ReTN");
		launcherPointer.put("gs_sg", "automation.SGGS");
		launcherPointer.put("net_init7", "automation.Init7");
		launcherPointer.put("net_savvis", "automation.Savvis");
		launcherPointer.put("net_i3d", "automation.I3D");
		launcherPointer.put("com_telx", "automation.TelX");
		launcherPointer.put("com_conit", "automation.ConIT");
		launcherPointer.put("net_inerail", "automation.Inerail");
		launcherPointer.put("com_core", "automation.CoreB");
		launcherPointer.put("net_vpls", "automation.VPLS");
		launcherPointer.put("net_pch", "automation.PCH");
		launcherPointer.put("edu_usc", "automation.USC");
		launcherPointer.put("edu_princeton", "automation.Princeton");
		launcherPointer.put("it_garr", "automation.GARR");
		launcherPointer.put("net_hlkomm", "automation.HLKomm");
		launcherPointer.put("com_cogent", "automation.Cogent");
		launcherPointer.put("no_uninett", "automation.UNINETT");
		launcherPointer.put("net_ilan", "automation.ILAN");
		launcherPointer.put("ca_eastlink", "automation.Eastlink");
		launcherPointer.put("de_belwue", "automation.BelWue");
		launcherPointer.put("ch_switch", "automation.SWITCHlan");
		launcherPointer.put("net_bell", "automation.Bell");
		launcherPointer.put("net_silesnet", "automation.SilesNet");
		launcherPointer.put("es_rediris", "automation.RedIRIS");
		launcherPointer.put("net_ja", "automation.JANET");
		launcherPointer.put("co_simbanet", "automation.SimbaNET");
		launcherPointer.put("ch_solnet", "automation.SolNet");
		launcherPointer.put("net_iprimus", "automation.IPrimus");
		launcherPointer.put("net_noris", "automation.Noris");
		launcherPointer.put("ie_heanet", "automation.HEAnet");
		launcherPointer.put("net_telstra", "automation.Telstra");
	}

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		// TODO code application logic here
//		String target = "8.8.8.8";https://www.bing.com/search?q=jsoup+post+and+retive+page&pc=MOZI&form=MOZSBR
		TraceLauncher tl = new TraceLauncher();
		tl.crawl();
	}

	private void crawl() {
		boolean run = false;

		String fileName = "running_camps.csv";
		String filePath = "./resources";
		String folderName = "./targetted_probing";
		String outFolder = (new File(new File(folderName), fileName)).toString();

		HashMap<String, HashSet> completed = new HashMap<String, HashSet>();
		File folder = new File(outFolder);
		if (folder.isDirectory()) {
			File[] files = folder.listFiles();
			for (File file : files) {
				if (file.isFile()) {
					String line = null;
					try {
//						System.out.println(file);

						String key = file.getName().split("-")[0];
						if (!completed.containsKey(key)) {
							completed.put(key, new HashSet());
						}

						BufferedReader br = new BufferedReader(new FileReader(file));

						String preamble = "********************* >>>> ";
						while ((line = br.readLine()) != null) {
							if (line.startsWith(preamble)) {
								String lineAux = line.replace("********************* >>>> ", "");
								completed.get(key).add(lineAux);
							}
						}
					} catch (IOException ex) {
						System.err.println(line);
						Logger.getLogger(TraceLauncher.class.getName()).log(Level.SEVERE, null, ex);
					} catch (java.lang.ArrayIndexOutOfBoundsException e) {
						System.err.println(line);
						Logger.getLogger(Launcher.class.getName()).log(Level.SEVERE, null, e);
						System.exit(-1);
					}
				}
			}
		} else if (makeFolder) {
			File outputDir = new File(outFolder);
			if (!outputDir.exists()) {
				outputDir.mkdirs();
			}
		} else {	//the path refers to a file name
			System.err.println("Outfolder is not created!!!");
			System.exit(2);
		}

		System.out.println("Completed from " + completed.size() + " Websites");
		for (Map.Entry<String, HashSet> entrySet : completed.entrySet()) {
			String key = entrySet.getKey();
			HashSet value = entrySet.getValue();
			System.out.println(key + " " + value.size());
		}
		

		HashMap<String, ArrayList<String>> campMap = new HashMap<String, ArrayList<String>>();
		File campaingFile = new File(new File(filePath), fileName);
		try {
			BufferedReader reader = new BufferedReader(new FileReader(campaingFile));
			String line = null;
			while ((line = reader.readLine()) != null) {

				String id = line.split("\t")[0];
				System.out.println(id + " >> " + line);
				
				if (completed.containsKey(id)) {
					if (completed.get(id).contains(line)) {
						continue;
					}
				}

				String classNameToBeLoaded = launcherPointer.get(id);
//				System.out.println(classNameToBeLoaded);

				if (!campMap.containsKey(classNameToBeLoaded)) {
					campMap.put(classNameToBeLoaded, new ArrayList<String>());
				}

				campMap.get(classNameToBeLoaded).add(line);

//				if (run) {
//					try {
//						ClassLoader classLoader = ClassLoader.getSystemClassLoader();
//
//						Class aClass = classLoader.loadClass(classNameToBeLoaded);
//						Object instance = aClass.newInstance();
//
//						Method methodConfig = aClass.getDeclaredMethod("config", new Class[]{String.class, String.class});
//						methodConfig.invoke(instance, new Object[]{line, folderName});
//
//						Method methodLaunch = aClass.getDeclaredMethod("launch", new Class[]{});
//						String returnValue = (String) methodLaunch.invoke(instance, new Object[]{});
//
//						System.out.println(returnValue);
//
//					} catch (ClassNotFoundException e) {
//						e.printStackTrace();
//					} catch (IllegalAccessException ex) {
//						Logger.getLogger(TraceLauncher.class.getName()).log(Level.SEVERE, null, ex);
//					} catch (InstantiationException ex) {
//						Logger.getLogger(TraceLauncher.class.getName()).log(Level.SEVERE, null, ex);
//					} catch (NoSuchMethodException ex) {
//						Logger.getLogger(TraceLauncher.class.getName()).log(Level.SEVERE, null, ex);
//					} catch (SecurityException ex) {
//						Logger.getLogger(TraceLauncher.class.getName()).log(Level.SEVERE, null, ex);
//					} catch (IllegalArgumentException ex) {
//						Logger.getLogger(TraceLauncher.class.getName()).log(Level.SEVERE, null, ex);
//					} catch (InvocationTargetException ex) {
//						Logger.getLogger(TraceLauncher.class.getName()).log(Level.SEVERE, null, ex);
//					}
//				}
			}
		} catch (FileNotFoundException ex) {
			Logger.getLogger(TraceLauncher.class.getName()).log(Level.SEVERE, null, ex);
		} catch (IOException ex) {
			Logger.getLogger(TraceLauncher.class.getName()).log(Level.SEVERE, null, ex);
		}
		
		ExecutorService s = Executors.newFixedThreadPool(campMap.size());
		for (Map.Entry<String, ArrayList<String>> entrySet : campMap.entrySet()) {
			
			String classToBeLoaded = entrySet.getKey();
			ArrayList<String> value = entrySet.getValue();
			System.out.println(classToBeLoaded + " => " + value.size());
			ExecuteManager em = new ExecuteManager(classToBeLoaded, outFolder, value);
			s.submit(em);
		}
	}

//	Launcher auto = new Level3();
//	((Level3) auto).config(line, outFolder);
//	((Level3) auto).launch();
//
//	System.exit(-1);
//
//	//no paramater
//	Class noparams[] = {};
//
//	//String parameter
//	Class[] paramString = new Class[2];
//	paramString[0] = String.class;
//	paramString[1] = String.class;
	private void dynClassLoaderExample() {
		try {
			ClassLoader myClassLoader = ClassLoader.getSystemClassLoader();

			// Step 2: Define a class to be loaded.
			String classNameToBeLoaded = "tracelauncher.DemoClass";

			// Step 3: Load the class
			Class myClass = myClassLoader.loadClass(classNameToBeLoaded);

			// Step 4: create a new instance of that class
			Object whatInstance = myClass.newInstance();

			String methodParameter = "a quick brown fox";

			// Step 5: get the method, with proper parameter signature.
			// The second parameter is the parameter type.
			// There can be multiple parameters for the method we are trying to call,
			// hence the use of array.
			Method myMethod = myClass.getMethod("demoMethod",
					new Class[]{String.class});

			// Step 6:
			// Calling the real method. Passing methodParameter as
			// parameter. You can pass multiple parameters based on
			// the signature of the method you are calling. Hence
			// there is an array.
			String returnValue = (String) myMethod.invoke(whatInstance,
					new Object[]{methodParameter});

			System.out.println("The value returned from the method is:"
					+ returnValue);
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
	}
}
